document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const formTitle = document.getElementById('formTitle');
    const switchForm = document.getElementById('switchForm');
    const switchToSignup = document.getElementById('switchToSignup');

    function toggleForms() {
        loginForm.style.display = loginForm.style.display === 'none' ? 'flex' : 'none';
        signupForm.style.display = signupForm.style.display === 'none' ? 'flex' : 'none';
        formTitle.textContent = loginForm.style.display === 'none' ? 'Sign Up' : 'Login';
        switchForm.innerHTML = loginForm.style.display === 'none' 
            ? 'Already have an account? <a href="#" id="switchToLogin">Login</a>'
            : 'Don\'t have an account? <a href="#" id="switchToSignup">Sign up</a>';
    }

    switchForm.addEventListener('click', (e) => {
        e.preventDefault();
        if (e.target.id === 'switchToSignup' || e.target.id === 'switchToLogin') {
            toggleForms();
        }
    });

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Here you would typically validate the login credentials
        // For this example, we'll just redirect to index.html
        window.location.href = 'index.html';
    });

    signupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Here you would typically handle the signup process
        // For this example, we'll just redirect to index.html
        window.location.href = 'index.html';
    });
});