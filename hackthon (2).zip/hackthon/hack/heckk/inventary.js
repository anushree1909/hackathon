document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const sidebar = document.querySelector('.sidebar');
    const navLinks = document.querySelectorAll('.nav-links a');
    const actionButtons = document.querySelectorAll('.action-btn');
    const addProductBtn = document.getElementById('add-product-btn');
    const addProductModal = document.getElementById('add-product-modal');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const addProductForm = document.getElementById('add-product-form');
    const productsData = document.getElementById('products-data');
    const imagePreview = document.getElementById('image-preview');
    const productImage = document.getElementById('product-image');
    const browseImageBtn = document.getElementById('browse-image');
    const discardBtn = document.getElementById('discard-btn');
    const barcodeScanBtn = document.getElementById('barcode-scan');
    const scannerModal = document.getElementById('scanner-modal');
    const scannerVideo = document.getElementById('scanner-video');
    let products = [
        
    ];


    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            navLinks.forEach(l => l.parentElement.classList.remove('active'));
            this.parentElement.classList.add('active');
        });
    });
    actionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.dataset.action;
            console.log(`Performing action: ${action}`);
        });
    });
    addProductBtn.addEventListener('click', () => {
        addProductModal.style.display = 'block';
        addProductModal.classList.add('fade-in');
    });
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            addProductModal.style.display = 'none';
            scannerModal.style.display = 'none';
        });
    });
    discardBtn.addEventListener('click', () => {
        addProductModal.style.display = 'none';
        addProductForm.reset();
        imagePreview.src = 'placeholder.png';
    });
    browseImageBtn.addEventListener('click', () => {
        productImage.click();
    });

    productImage.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    addProductForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(addProductForm);
        const newProduct = Object.fromEntries(formData.entries());
        
        products.push({
            name: newProduct.productName,
            buyingPrice: `₹${newProduct.buyingPrice}`,
            quantity: `${newProduct.quantity} `,
            threshold: `${newProduct.threshold}`,
            expiryDate: newProduct.expiryDate,
            status: 'In stock'
        });
        updateProductsTable();

        addProductModal.style.display = 'none';
        addProductForm.reset();
        imagePreview.src = 'placeholder.png';
    });
    function updateProductsTable() {
        productsData.innerHTML = '';
        products.forEach(product => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${product.name}</td>
                <td>${product.buyingPrice}</td>
                <td>${product.quantity}</td>
                <td>${product.threshold}</td>
                <td>${product.expiryDate}</td>
                <td>${product.status}</td>
            `;
            productsData.appendChild(row);
        });
    }
    updateProductsTable();
    barcodeScanBtn.addEventListener('click', () => {
        scannerModal.style.display = 'block';
        scannerModal.classList.add('fade-in');
        startBarcodeScanner();
    });

    function startBarcodeScanner() {
        Quagga.init({
            inputStream: {
                name: "Live",
                type: "LiveStream",
                target: scannerVideo
            },
            decoder: {
                readers: ["ean_reader", "ean_8_reader", "code_128_reader"]
            }
        }, function(err) {
            if (err) {
                console.error(err);
                return;
            }
            Quagga.start();
        });

        Quagga.onDetected(function(result) {
            const code = result.codeResult.code;
            document.getElementById('barcode').value = code;
            scannerModal.style.display = 'none';
            Quagga.stop();
        });
    }

    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Add animations to elements
    const animatedElements = document.querySelectorAll('.stat-card, .products-section');
    animatedElements.forEach(el => {
        el.classList.add('slide-in');
    });
  
});
