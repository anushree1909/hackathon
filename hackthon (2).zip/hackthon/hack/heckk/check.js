document.addEventListener('DOMContentLoaded', function() {
    const addProductForm = document.getElementById('addProductForm');
    const productList = document.getElementById('productList');
    const totalAmountSpan = document.getElementById('totalAmount');
    const submitOrderButton = document.getElementById('submitOrder');

    let products = [];
    let totalAmount = 0;

    function updateProductList() {
        productList.innerHTML = '';
        products.forEach((product, index) => {
            const li = document.createElement('li');
            li.innerHTML = `
                <span>${product.name} - $${product.price.toFixed(2)}</span>
                <button class="remove-btn" data-index="${index}">Remove</button>
            `;
            productList.appendChild(li);
        });
    }

    function updateTotalAmount() {
        totalAmount = products.reduce((sum, product) => sum + product.price, 0);
        totalAmountSpan.textContent = totalAmount.toFixed(2);
    }

    addProductForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('productName').value;
        const price = parseFloat(document.getElementById('productPrice').value);

        if (name && !isNaN(price)) {
            products.push({ name, price });
            updateProductList();
            updateTotalAmount();
            addProductForm.reset();
        }
    });

    productList.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-btn')) {
            const index = parseInt(e.target.getAttribute('data-index'));
            products.splice(index, 1);
            updateProductList();
            updateTotalAmount();
        }
    });

    submitOrderButton.addEventListener('click', function() {
        if (products.length > 0) {
            alert(`Order submitted successfully! Total amount: $${totalAmount.toFixed(2)}`);
            products = [];
            updateProductList();
            updateTotalAmount();
        } else {
            alert('Please add at least one product before submitting the order.');
        }
    });
});