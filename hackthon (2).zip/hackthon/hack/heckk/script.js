import React, { useState, useEffect } from 'react';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, Title, Tooltip, Legend);

export default function Dashboard() {
  const [salesData, setSalesData] = useState([]);
  const [inventoryData, setInventoryData] = useState([]);
  const [orderData, setOrderData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const salesResponse = await fetch('http://localhost:5000/api/sales');
      const salesData = await salesResponse.json();
      setSalesData(salesData);

      const inventoryResponse = await fetch('http://localhost:5000/api/inventory');
      const inventoryData = await inventoryResponse.json();
      setInventoryData(inventoryData);

      const orderResponse = await fetch('http://localhost:5000/api/orders');
      const orderData = await orderResponse.json();
      setOrderData(orderData);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const salesPurchaseChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Sales',
        data: salesData.map(sale => sale.amount),
        backgroundColor: 'rgba(46, 204, 113, 0.6)',
        borderColor: 'rgba(46, 204, 113, 1)',
        borderWidth: 1
      },
      {
        label: 'Purchase',
        data: orderData.map(order => order.products.reduce((total, product) => total + product.quantity, 0)),
        backgroundColor: 'rgba(52, 152, 219, 0.6)',
        borderColor: 'rgba(52, 152, 219, 1)',
        borderWidth: 1
      }
    ]
  };

  const orderSummaryChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
    datasets: [
      {
        label: 'Ordered',
        data: orderData.filter(order => order.status === 'Ordered').map(order => order.products.reduce((total, product) => total + product.quantity, 0)),
        borderColor: 'rgba(231, 76, 60, 1)',
        tension: 0.4,
        fill: false
      },
      {
        label: 'Delivered',
        data: orderData.filter(order => order.status === 'Delivered').map(order => order.products.reduce((total, product) => total + product.quantity, 0)),
        borderColor: 'rgba(46, 204, 113, 1)',
        tension: 0.4,
        fill: false
      }
    ]
  };

  const topSellingStock = inventoryData
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 3)
    .map(item => ({
      name: item.product,
      soldQuantity: salesData.filter(sale => sale.product === item.product).reduce((total, sale) => total + sale.amount, 0),
      remainingQuantity: item.quantity,
      price: `₹ ${item.price}`
    }));

  const lowQuantityStock = inventoryData
    .filter(item => item.quantity <= 15)
    .slice(0, 3)
    .map(item => ({
      name: item.product,
      quantity: item.quantity,
    
    }));

  return (
    <div className="dashboard-grid">
      <div className="card sales-overview">
        <h2>Sales Overview</h2>
        <Bar data={salesPurchaseChartData} />
      </div>
      <div className="card order-summary">
        <h2>Order Summary</h2>
        <Line data={orderSummaryChartData} />
      </div>
      <div className="card top-selling-stock">
        <h2>Top Selling Stock</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Sold Quantity</th>
              <th>Remaining Quantity</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {topSellingStock.map((item, index) => (
              <tr key={index}>
                <td>{item.name}</td>
                <td>{item.soldQuantity}</td>
                <td>{item.remainingQuantity}</td>
                <td>{item.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="card low-quantity-stock">
        <h2>Low Quantity Stock</h2>
        <div id="lowQuantityStockItems">
          {lowQuantityStock.map((item, index) => (
            <div key={index} className="low-quantity-item">
              <img src={item.image} alt={item.name} />
              <div className="details">
                <div className="name">{item.name}</div>
                <div className="quantity">Remaining Quantity: {item.quantity} Packet</div>
              </div>
              <span className="low-tag">Low</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}