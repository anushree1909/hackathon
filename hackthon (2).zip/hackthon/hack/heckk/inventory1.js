import React, { useState, useEffect } from 'react';

export default function InventoryManagement() {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({
    name: '',
    barcode: '',
    category: '',
    buyingPrice: '',
    quantity: '',
    unit: '',
    expiryDate: '',
    threshold: ''
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/products');
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleInputChange = (e) => {
    setNewProduct({ ...newProduct, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newProduct),
      });
      const data = await response.json();
      setProducts([...products, data]);
      setNewProduct({
        name: '',
        barcode: '',
        category: '',
        buyingPrice: '',
        quantity: '',
        unit: '',
        expiryDate: '',
        threshold: ''
      });
      document.getElementById('add-product-modal').style.display = 'none';
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  return (
    <div>
      <h1>Inventory Management</h1>
      <button onClick={() => document.getElementById('add-product-modal').style.display = 'block'}>
        Add Product
      </button>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Buying Price</th>
            <th>Quantity</th>
            <th>Threshold</th>
            <th>Expiry Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product._id}>
              <td>{product.name}</td>
              <td>{product.buyingPrice}</td>
              <td>{product.quantity}</td>
              <td>{product.threshold}</td>
              <td>{new Date(product.expiryDate).toLocaleDateString()}</td>
              <td>{product.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div id="add-product-modal" style={{display: 'none'}}>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            value={newProduct.name}
            onChange={handleInputChange}
            placeholder="Product Name"
            required
          />
          <input
            type="text"
            name="barcode"
            value={newProduct.barcode}
            onChange={handleInputChange}
            placeholder="Barcode"
            required
          />
          <select
            name="category"
            value={newProduct.category}
            onChange={handleInputChange}
            required
          >
            <option value="">Select category</option>
            <option value="beverages">Beverages</option>
            <option value="snacks">Snacks</option>
            <option value="groceries">Groceries</option>
          </select>
          <input
            type="number"
            name="buyingPrice"
            value={newProduct.buyingPrice}
            onChange={handleInputChange}
            placeholder="Buying Price"
            required
          />
          <input
            type="number"
            name="quantity"
            value={newProduct.quantity}
            onChange={handleInputChange}
            placeholder="Quantity"
            required
          />
          <input
            type="text"
            name="unit"
            value={newProduct.unit}
            onChange={handleInputChange}
            placeholder="Unit"
            required
          />
          <input
            type="date"
            name="expiryDate"
            value={newProduct.expiryDate}
            onChange={handleInputChange}
            required
          />
          <input
            type="number"
            name="threshold"
            value={newProduct.threshold}
            onChange={handleInputChange}
            placeholder="Threshold Value"
            required
          />
          <button type="submit">Add Product</button>
        </form>
      </div>
    </div>
  );
}