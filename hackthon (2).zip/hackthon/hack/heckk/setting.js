// DOM Elements
const profilePic = document.getElementById('profilePic');
const profilePicInput = document.getElementById('profilePicInput');
const nameInput = document.getElementById('nameInput');
const saveName = document.getElementById('saveName');
const currentPassword = document.getElementById('currentPassword');
const newPassword = document.getElementById('newPassword');
const confirmPassword = document.getElementById('confirmPassword');
const changePassword = document.getElementById('changePassword');
const logout = document.getElementById('logout');

// Event Listeners
profilePicInput.addEventListener('change', updateProfilePic);
saveName.addEventListener('click', updateName);
changePassword.addEventListener('click', updatePassword);
logout.addEventListener('click', logoutUser);

// Functions
function updateProfilePic(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            profilePic.src = e.target.result;
            // Here you would typically upload the image to your server
            console.log('Profile picture updated');
        }
        reader.readAsDataURL(file);
    }
}

function updateName() {
    const newName = nameInput.value.trim();
    if (newName) {
        // Here you would typically send the new name to your server
        console.log('Name updated to:', newName);
        alert('Name updated successfully!');
    } else {
        alert('Please enter a valid name');
    }
}

function updatePassword() {
    const current = currentPassword.value;
    const newPass = newPassword.value;
    const confirmPass = confirmPassword.value;

    if (!current || !newPass || !confirmPass) {
        alert('Please fill in all password fields');
        return;
    }

    if (newPass !== confirmPass) {
        alert('New passwords do not match');
        return;
    }

    // Here you would typically send the password change request to your server
    console.log('Password change requested');
    alert('Password changed successfully!');

    // Clear password fields
    currentPassword.value = '';
    newPassword.value = '';
    confirmPassword.value = '';
}

function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        // Here you would typically send a logout request to your server
        console.log('User logged out');
        alert('You have been logged out');
        // Redirect to login page or home page
        // window.location.href = 'login.html';
    }
}

// Initialize
function init() {
    // Here you would typically fetch the user's current data from your server
    // and populate the form fields
    nameInput.value = 'Abhi'; // Example
}

init();