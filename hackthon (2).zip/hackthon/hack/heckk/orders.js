// Initialize Lucide icons
document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
});

// Sample data for orders
const orders = [
    {
        id: "1",
        product: "Maggi",
        value: 4306,
        quantity: "43 Packets",
        orderId: "7535",
        expectedDelivery: "11/12/22",
        status: "Delayed"
    },
    {
        id: "2",
        product: "Bru",
        value: 2557,
        quantity: "22 Packets",
        orderId: "5724",
        expectedDelivery: "21/12/22",
        status: "Confirmed"
    },
];

function populateOrdersTable() {
    const tableBody = document.getElementById('ordersTableBody');
    if (!tableBody) {
        console.error('Table body element not found');
        return;
    }
    tableBody.innerHTML = '';

    orders.forEach(order => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${order.product}</td>
            <td>₹${order.value}</td>
            <td>${order.quantity}</td>
            <td>${order.orderId}</td>
            <td>${order.expectedDelivery}</td>
            <td><span class="badge ${order.status.toLowerCase()}">${order.status}</span></td>
        `;
        tableBody.appendChild(row);
    });
}

// Modal functionality
function setupModal() {
    const modal = document.getElementById('addProductModal');
    const addProductBtn = document.getElementById('addProductBtn');
    const discardBtn = document.getElementById('discardBtn');
    const addProductForm = document.getElementById('addProductForm');

    if (!modal || !addProductBtn || !discardBtn || !addProductForm) {
        console.error('One or more modal elements not found');
        return;
    }

    addProductBtn.onclick = function() {
        modal.style.display = "block";
    }

    discardBtn.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    addProductForm.onsubmit = function(e) {
        e.preventDefault();
        const formData = new FormData(addProductForm);
        const newProduct = {
            id: Math.random().toString(),
            product: formData.get('productName'),
            value: parseInt(formData.get('orderValue')),
            quantity: `${formData.get('quantity')} ${formData.get('unit')}`,
            orderId: Math.floor(Math.random() * 10000).toString(),
            expectedDelivery: formData.get('deliveryDate'),
            status: "Confirmed"
        };
        orders.unshift(newProduct);
        populateOrdersTable();
        modal.style.display = "none";
        addProductForm.reset();
    }
}

// Add some basic animations
function setupAnimations() {
    document.querySelectorAll('.nav-button, .action-button').forEach(button => {
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'translateX(5px)';
        });
        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translateX(0)';
        });
    });
}

// Add a simple loading animation
function setupLoadingAnimation() {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s ease-in';
        document.body.style.opacity = '1';
    }, 100);
}

// Main initialization function
function init() {
    populateOrdersTable();
    setupModal();
    setupAnimations();
    setupLoadingAnimation();
}

// Call the initialization function when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', init);