document.addEventListener('DOMContentLoaded', function() {

    const addSupplierBtn = document.getElementById('add-supplier-btn');
    const addSupplierModal = document.getElementById('add-supplier-modal');
    const closeModalBtn = document.querySelector('.close-modal');
    const addSupplierForm = document.getElementById('add-supplier-form');
    const suppliersData = document.getElementById('suppliers-data');
    const imagePreview = document.getElementById('image-preview');
    const supplierImage = document.getElementById('supplier-image');
    const browseImageBtn = document.getElementById('browse-image');
    const discardBtn = document.getElementById('discard-btn');

    let suppliers = [];

    addSupplierBtn.addEventListener('click', () => {
        addSupplierModal.classList.add('active');
    });

    closeModalBtn.addEventListener('click', closeModal);
    discardBtn.addEventListener('click', closeModal);

    function closeModal() {
        addSupplierModal.classList.remove('active');
        addSupplierForm.reset();
        imagePreview.src = '/placeholder.svg?height=100&width=100';
    }

    browseImageBtn.addEventListener('click', () => {
        supplierImage.click();
    });

    supplierImage.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    addSupplierForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(addSupplierForm);
        const newSupplier = Object.fromEntries(formData.entries());
        
    
        newSupplier.imageUrl = imagePreview.src;

        
        suppliers.push(newSupplier);
        updateSuppliersTable();

        closeModal();
    });

    function updateSuppliersTable() {
        suppliersData.innerHTML = '';
        suppliers.forEach(supplier => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${supplier.supplierName}</td>
                <td>${supplier.product}</td>
                <td>${supplier.contactNumber}</td>
                <td>${supplier.email}</td>
                <td>${supplier.type}</td>
                <td>-</td>
            `;
            suppliersData.appendChild(row);
        });
    }

    suppliers = [
        
    ];
    updateSuppliersTable();

    const ctx = document.getElementById('profitRevenueChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
            datasets: [{
                label: 'Revenue',
                data: [30000, 35000, 32000, 40000, 38000, 42000, 45000],
                borderColor: '#ff7e67',
                backgroundColor: 'rgba(255, 126, 103, 0.1)',
                tension: 0.4
            }, {
                label: 'Profit',
                data: [15000, 18000, 16000, 22000, 20000, 23000, 25000],
                borderColor: '#ffa41b',
                backgroundColor: 'rgba(255, 164, 27, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: false,
                    text: 'Profit & Revenue'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value, index, values) {
                            return '₹' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });

    const chartPeriod = document.getElementById('chart-period');
    chartPeriod.addEventListener('change', function() {
        chart.data.datasets[0].data = generateRandomData(7, 30000, 50000);
        chart.data.datasets[1].data = generateRandomData(7, 15000, 30000);
        chart.update();
    });
    function generateRandomData(count, min, max) {
        return Array.from({length: count}, () => Math.floor(Math.random() * (max - min + 1) + min));
    }

    const navLinks = document.querySelectorAll('.nav-links a, .bottom-nav a');
    const pageSections = document.querySelectorAll('.page-section');

    function showSection(sectionId) {
        pageSections.forEach(section => {
            section.style.display = section.id === sectionId ? 'block' : 'none';
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionId = this.dataset.section;
            
            navLinks.forEach(l => l.parentElement.classList.remove('active'));
            this.parentElement.classList.add('active');
            
            showSection(sectionId);
        });
    });

    showSection('reports');

    const actionButtons = document.querySelectorAll('.action-btn');
    actionButtons.forEach(button => {
        button.addEventListener('click', function() {
            alert(`Performing action: ${this.dataset.action}`);
        });
    });

    setTimeout(() => {
        document.querySelectorAll('table').forEach(table => {
            table.style.opacity = '1';
        });
    }, 1000);


    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Add a simple animation to the overview cards
    const overviewItems = document.querySelectorAll('.overview-item');
    overviewItems.forEach((item, index) => {
        item.style.animationDelay = `${index * 0.1}s`;
    });
});