document.addEventListener('DOMContentLoaded', function() {

    const ctx = document.getElementById('profitRevenueChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            // Add your chart data here
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value, index, values) {
                            return '' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });

    const chartPeriod = document.getElementById('chart-period');
    chartPeriod.addEventListener('change', function() {
        chart.update();
    });

    function generateRandomData(count, min, max) {
        return Array.from({length: count}, () => Math.floor(Math.random() * (max - min + 1) + min));
    }

    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            navLinks.forEach(l => l.parentElement.classList.remove('active'));
            this.parentElement.classList.add('active');
            console.log(`Navigating to ${this.dataset.section}`);
        });
    });

    const actionButtons = document.querySelectorAll('.action-btn');
    actionButtons.forEach(button => {
        button.addEventListener('click', function() {
            console.log(`Performing action: ${this.dataset.action}`);
        });
    });

    const bottomNavLinks = document.querySelectorAll('.bottom-nav a');
    bottomNavLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            console.log(`Navigating to ${this.dataset.section}`);
        });
    });

    setTimeout(() => {
        document.querySelectorAll('table').forEach(table => {
            table.style.opacity = '1';
        });
    }, 1000);

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    const overviewItems = document.querySelectorAll('.overview-item');
    overviewItems.forEach((item, index) => {
        item.style.animationDelay = `${index * 0.1}s`;
    });

    document.querySelectorAll('.sidebar a').forEach(link => {
        link.addEventListener('click', (e) => {
            document.querySelector('.sidebar .active').classList.remove('active');
            link.parentElement.classList.add('active');
        });
    });
});
