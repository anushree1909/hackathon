// Sample data for stores
let stores = [
    {
        id: 1,
        branchName: "Singanallur Branch",
        storeName: "Lisy Store",
        address: "123 Krishnaswamy layout, 3 rd street sulur",
        city: "Coimbatore",
        pincode: "641402",
        phone: "044-653578"
    },
    {
        id: 2,
        branchName: "Siur Branch",
        storeName: "Lisy Store",
        address: "54 Ramani colony, 3 rd street sulur",
        city: "Coimbatore",
        pincode: "641452",
        phone: "044-653763"
    },
    {
        id: 3,
        branchName: "Gaandipuram Branch",
        storeName: "Lisy Store",
        address: "32/1 Venkatasamy layout, 3 rd street sulur",
        city: "Coimbatore",
        pincode: "641403",
        phone: "044-653578"
    }
];

// DOM Elements
const storesList = document.getElementById('storesList');
const addStoreBtn = document.getElementById('addStoreBtn');
const addStoreModal = document.getElementById('addStoreModal');
const editStoreModal = document.getElementById('editStoreModal');
const addStoreForm = document.getElementById('addStoreForm');
const editStoreForm = document.getElementById('editStoreForm');
const discardBtn = document.getElementById('discardBtn');
const editDiscardBtn = document.getElementById('editDiscardBtn');
const closeButtons = document.querySelectorAll('.close-button');

// Functions
function displayStores() {
    storesList.innerHTML = '';
    stores.forEach(store => {
        const storeCard = document.createElement('div');
        storeCard.className = 'store-card';
        storeCard.innerHTML = `
            <div class="branch-name">
                <h3>${store.branchName}</h3>
            </div>
            <div class="store-info">
                <h3>${store.storeName}</h3>
                <p>${store.address}</p>
                <p>${store.city} - ${store.pincode}</p>
                <p>${store.phone}</p>
            </div>
            <div class="store-actions">
                <button class="button outline" onclick="editStore(${store.id})">Edit</button>
            </div>
        `;
        storesList.appendChild(storeCard);
    });
}

function showModal(modal) {
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function hideModal(modal) {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

function editStore(id) {
    const store = stores.find(s => s.id === id);
    if (store) {
        document.getElementById('editStoreId').value = store.id;
        document.getElementById('editBranchName').value = store.branchName;
        document.getElementById('editStoreName').value = store.storeName;
        document.getElementById('editAddress').value = store.address;
        document.getElementById('editCity').value = store.city;
        document.getElementById('editPincode').value = store.pincode;
        document.getElementById('editPhone').value = store.phone;
        showModal(editStoreModal);
    }
}

// Event Listeners
addStoreBtn.addEventListener('click', () => showModal(addStoreModal));
discardBtn.addEventListener('click', () => hideModal(addStoreModal));
editDiscardBtn.addEventListener('click', () => hideModal(editStoreModal));

closeButtons.forEach(button => {
    button.addEventListener('click', () => {
        hideModal(button.closest('.modal'));
    });
});

window.addEventListener('click', (event) => {
    if (event.target === addStoreModal) {
        hideModal(addStoreModal);
    }
    if (event.target === editStoreModal) {
        hideModal(editStoreModal);
    }
});

addStoreForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const newStore = {
        id: stores.length + 1,
        branchName: document.getElementById('branchName').value,
        storeName: document.getElementById('storeName').value,
        address: document.getElementById('address').value,
        city: document.getElementById('city').value,
        pincode: document.getElementById('pincode').value,
        phone: document.getElementById('phone').value
    };
    stores.push(newStore);
    displayStores();
    hideModal(addStoreModal);
    addStoreForm.reset();
});

editStoreForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const id = parseInt(document.getElementById('editStoreId').value);
    const storeIndex = stores.findIndex(s => s.id === id);
    if (storeIndex !== -1) {
        stores[storeIndex] = {
            id: id,
            branchName: document.getElementById('editBranchName').value,
            storeName: document.getElementById('editStoreName').value,
            address: document.getElementById('editAddress').value,
            city: document.getElementById('editCity').value,
            pincode: document.getElementById('editPincode').value,
            phone: document.getElementById('editPhone').value
        };
        displayStores();
        hideModal(editStoreModal);
    }
});

// Add animations to nav buttons
document.querySelectorAll('.nav-button, .action-button').forEach(button => {
    button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateX(5px)';
    });
    button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateX(0)';
    });
});

// Initialize
displayStores();