document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-links a');
    const actionButtons = document.querySelectorAll('.action-btn');
    const searchInput = document.querySelector('.search-bar input');
    const searchBtn = document.querySelector('.search-btn');
    const content = document.getElementById('content');
    const userProfileImg = document.querySelector('.user-profile img');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.dataset.section;
            
            navLinks.forEach(l => l.parentElement.classList.remove('active'));
            this.parentElement.classList.add('active');
            

            content.innerHTML = `<h1>${section.charAt(0).toUpperCase() + section.slice(1)}</h1><p>Content for ${section} goes here.</p>`;
        });
    });

    actionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.dataset.action;
            switch(action) {
                case 'create-order':
                    alert('Creating a new order...');
                    
                    break;
                case 'add-product':
                    alert('Adding a new product...');
                    
                    break;
                case 'add-supplier':
                    alert('Adding a new supplier...');
                    
                    break;
                case 'export':
                    alert('Exporting data...');
                    
                    break;
                case 'settings':
                    alert('Opening settings...');
                    
                    break;
                case 'logout':
                    alert('Logging out...');
                    
                    break;
                default:
                    alert(`Performing action: ${action}`);
            }
        });
    });

    
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });

    function performSearch() {
        const searchTerm = searchInput.value.trim();
        if (searchTerm) {
            alert(`Searching for: ${searchTerm}`);
            
            content.innerHTML = `
                <h1>Search Results</h1>
                <p>Showing results for: "${searchTerm}"</p>
                <ul>
                    <li>Result 1 for ${searchTerm}</li>
                    <li>Result 2 for ${searchTerm}</li>
                    <li>Result 3 for ${searchTerm}</li>
                </ul>
            `;
        }
    }

    // User profile functionality
    userProfileImg.addEventListener('click', function() {
        alert('Opening user profile settings...');
        // Add logic for opening user profile or settings
    });

    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Responsive sidebar toggle (for mobile devices)
    const sidebarToggle = document.createElement('button');
    sidebarToggle.textContent = '☰';
    sidebarToggle.classList.add('sidebar-toggle');
    document.body.appendChild(sidebarToggle);

    sidebarToggle.addEventListener('click', function() {
        document.querySelector('.sidebar').classList.toggle('active');
    });

    // Close sidebar when clicking outside (for mobile devices)
    document.addEventListener('click', function(event) {
        const sidebar = document.querySelector('.sidebar');
        const isClickInsideSidebar = sidebar.contains(event.target);
        const isClickOnToggle = sidebarToggle.contains(event.target);

        if (!isClickInsideSidebar && !isClickOnToggle && sidebar.classList.contains('active')) {
            sidebar.classList.remove('active');
        }
    });
});