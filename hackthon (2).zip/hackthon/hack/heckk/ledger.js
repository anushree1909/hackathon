// Sample data for ledger entries
let ledgerEntries = [
 
];

// DOM Elements
const ledgerTableBody = document.getElementById('ledgerTableBody');
const addCustomerBtn = document.getElementById('addCustomerBtn');
const addCustomerModal = document.getElementById('addCustomerModal');
const addCustomerForm = document.getElementById('addCustomerForm');
const discardBtn = document.getElementById('discardBtn');
const closeButtons = document.querySelectorAll('.close-button');

// Functions
function displayLedgerEntries() {
    ledgerTableBody.innerHTML = '';
    ledgerEntries.forEach(entry => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${entry.customer}</td>
            <td>₹${entry.orderValue}</td>
            <td>${entry.items} <button class="view-items">></button></td>
            <td>${entry.dueAmount}</td>
            <td>${entry.dueDate}</td>
            <td><span class="status ${entry.status}">${entry.status}</span></td>
        `;
        ledgerTableBody.appendChild(row);
    });
}

function showModal(modal) {
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function hideModal(modal) {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

function updateOverviewStats() {
    const totalDues = ledgerEntries.length;
    const totalReceived = ledgerEntries.filter(entry => entry.status === 'paid')
        .reduce((sum, entry) => sum + entry.orderValue, 0);
    const totalPending = ledgerEntries.filter(entry => entry.status === 'pending').length;
    const unpaid = ledgerEntries.filter(entry => entry.status === 'unpaid').length;
    const unpaidAmount = ledgerEntries.filter(entry => entry.status === 'unpaid')
        .reduce((sum, entry) => sum + entry.dueAmount, 0);

    // Update the overview cards
    document.querySelector('.overview-cards .blue + .value').textContent = totalDues;
    document.querySelector('.overview-cards .orange + .value').textContent = `₹${totalReceived}`;
    document.querySelector('.overview-cards .purple + .value').textContent = totalPending;
    document.querySelector('.overview-cards .red + .value').textContent = unpaid;
    document.querySelector('.overview-cards .red + .value + .value-small').textContent = `₹${unpaidAmount}`;
}

// Event Listeners
addCustomerBtn.addEventListener('click', () => showModal(addCustomerModal));
discardBtn.addEventListener('click', () => hideModal(addCustomerModal));

closeButtons.forEach(button => {
    button.addEventListener('click', () => {
        hideModal(button.closest('.modal'));
    });
});

window.addEventListener('click', (event) => {
    if (event.target === addCustomerModal) {
        hideModal(addCustomerModal);
    }
});

addCustomerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const newCustomer = {
        id: ledgerEntries.length + 1,
        customer: document.getElementById('customerName').value,
        orderValue: parseInt(document.getElementById('orderValue').value),
        items: parseInt(document.getElementById('items').value),
        dueAmount: parseInt(document.getElementById('dueAmount').value),
        dueDate: document.getElementById('dueDate').value,
        status: 'pending'
    };
    ledgerEntries.push(newCustomer);
    displayLedgerEntries();
    updateOverviewStats();
    hideModal(addCustomerModal);
    addCustomerForm.reset();
});

// Add animations to nav buttons
document.querySelectorAll('.nav-button, .action-button').forEach(button => {
    button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateX(5px)';
    });
    button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateX(0)';
    });
});

// Initialize
displayLedgerEntries();
updateOverviewStats();

// Add a simple loading animation
window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s ease-in';
        document.body.style.opacity = '1';
    }, 100);
});

// Responsive sidebar toggle
const menuToggle = document.createElement('button');
menuToggle.classList.add('menu-toggle');
menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
document.querySelector('header').prepend(menuToggle);

menuToggle.addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('show');
});

// Close sidebar when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.sidebar') && !e.target.closest('.menu-toggle')) {
        document.querySelector('.sidebar').classList.remove('show');
    }
});