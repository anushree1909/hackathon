function generateRandomData(count, min, max) {
    return Array.from({ length: count }, () => Math.floor(Math.random() * (max - min + 1)) + min);
}

const salesPurchaseCtx = document.getElementById('salesPurchaseChart').getContext('2d');
const salesPurchaseChart = new Chart(salesPurchaseCtx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
            {
                label: 'Sales',
                data: generateRandomData(12, 20000, 60000),
                backgroundColor: 'rgba(46, 204, 113, 0.6)',
                borderColor: 'rgba(46, 204, 113, 1)',
                borderWidth: 1
            },
            {
                label: 'Purchase',
                data: generateRandomData(12, 15000, 50000),
                backgroundColor: 'rgba(52, 152, 219, 0.6)',
                borderColor: 'rgba(52, 152, 219, 1)',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

const orderSummaryCtx = document.getElementById('orderSummaryChart').getContext('2d');
const orderSummaryChart = new Chart(orderSummaryCtx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        datasets: [
            {
                label: 'Ordered',
                data: generateRandomData(5, 1000, 4000),
                borderColor: 'rgba(231, 76, 60, 1)',
                tension: 0.4,
                fill: false
            },
            {
                label: 'Delivered',
                data: generateRandomData(5, 1000, 4000),
                borderColor: 'rgba(46, 204, 113, 1)',
                tension: 0.4,
                fill: false
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

const topSellingStockData = [
    { name: 'Surf Excel', soldQuantity: 30, remainingQuantity: 12, price: '₹ 100' },
    { name: 'Rin', soldQuantity: 21, remainingQuantity: 15, price: '₹ 207' },
    { name: 'Parle G', soldQuantity: 19, remainingQuantity: 17, price: '₹ 105' }
];

const topSellingStockBody = document.getElementById('topSellingStockBody');
topSellingStockData.forEach(item => {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.soldQuantity}</td>
        <td>${item.remainingQuantity}</td>
        <td>${item.price}</td>
    `;
    topSellingStockBody.appendChild(row);
});
const lowQuantityStockData = [
    { name: 'Tata Salt', quantity: 10, image: 'https://example.com/tata-salt.jpg' },
    { name: 'Lays', quantity: 15, image: 'https://example.com/lays.jpg' },
    { name: 'Lays', quantity: 15, image: 'https://example.com/lays.jpg' }
];

const lowQuantityStockItems = document.getElementById('lowQuantityStockItems');
lowQuantityStockData.forEach(item => {
    const itemElement = document.createElement('div');
    itemElement.className = 'low-quantity-item';
    itemElement.innerHTML = `
        <img src="${item.image}" alt="${item.name}">
        <div class="details">
            <div class="name">${item.name}</div>
            <div class="quantity">Remaining Quantity: ${item.quantity} Packet</div>
        </div>
        <span class="low-tag">Low</span>
    `;
    lowQuantityStockItems.appendChild(itemElement);
});
document.getElementById('lowQuantitySeeAll').addEventListener('click', () => {
    alert('Show all low quantity stock items');
});

document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        card.style.transform = 'scale(1.05)';
        card.style.transition = 'transform 0.3s ease-in-out';
    });

    card.addEventListener('mouseleave', () => {
        card.style.transform = 'scale(1)';
    });
});

document.querySelectorAll('.sidebar a').forEach(link => {
    link.addEventListener('click', (e) => {
        document.querySelector('.sidebar .active').classList.remove('active');
        link.parentElement.classList.add('active');
    });
});
