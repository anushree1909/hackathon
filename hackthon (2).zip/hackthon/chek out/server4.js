const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const connectDB = require('./db');
const Order = require('./models/Order');

const app = express();
const port = process.env.PORT || 3000;

// Connect to MongoDB
connectDB();

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'checkout.html'));
});

app.post('/api/orders', async (req, res) => {
    try {
        const orderData = req.body;
        orderData.total = orderData.items.reduce((total, item) => total + item.price * item.quantity, 0);

        const order = new Order(orderData);
        await order.save();

        res.json({ success: true, orderId: order._id });
    } catch (error) {
        console.error('Error saving order:', error);
        res.status(500).json({ success: false, error: 'Error saving order' });
    }
});

// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});