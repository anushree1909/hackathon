document.addEventListener('DOMContentLoaded', function() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    const checkoutForm = document.getElementById('checkoutForm');

    // Simulated cart data (replace with actual data from your cart system)
    const cart = [
        { name: 'Product 1', price: 19.99, quantity: 2 },
        { name: 'Product 2', price: 29.99, quantity: 1 },
        { name: 'Product 3', price: 9.99, quantity: 3 }
    ];

    // Populate cart summary
    function updateCartSummary() {
        cartItems.innerHTML = '';
        let total = 0;

        cart.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.name} x${item.quantity} - $${(item.price * item.quantity).toFixed(2)}`;
            cartItems.appendChild(li);
            total += item.price * item.quantity;
        });

        cartTotal.textContent = `$${total.toFixed(2)}`;
    }

    updateCartSummary();

    // Handle form submission
    checkoutForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(checkoutForm);
        const orderData = Object.fromEntries(formData.entries());

        // Add cart items to order data
        orderData.items = cart;

        // Send order data to server
        fetch('/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Order placed successfully!');
                // Clear form and cart
                checkoutForm.reset();
                cart.length = 0;
                updateCartSummary();
            } else {
                alert('Error placing order. Please try again.');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            alert('An error occurred. Please try again later.');
        });
    });
});