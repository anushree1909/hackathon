// Mock data for products
const products = [
    { id: 1, name: 'Maggi', price: 430, image: '/placeholder.svg?height=100&width=100' },
    { id: 2, name: 'Bru', price: 257, image: '/placeholder.svg?height=100&width=100' },
    { id: 3, name: 'Red Bull', price: 405, image: '/placeholder.svg?height=100&width=100' },
    { id: 4, name: 'Bourn Vita', price: 502, image: '/placeholder.svg?height=100&width=100' },
    { id: 5, name: 'Horlicks', price: 530, image: '/placeholder.svg?height=100&width=100' },
];

let cart = [];

// DOM elements
const productGrid = document.getElementById('productGrid');
const searchInput = document.getElementById('searchInput');
const cartButton = document.getElementById('cartButton');
const cartPanel = document.getElementById('cartPanel');
const closeCart = document.getElementById('closeCart');
const cartItems = document.getElementById('cartItems');
const cartCount = document.getElementById('cartCount');
const cartTotal = document.getElementById('cartTotal');

// Render products
function renderProducts(productsToRender) {
    productGrid.innerHTML = '';
    productsToRender.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-price">₹${product.price}</p>
                <button class="add-to-cart-button" data-id="${product.id}">Add to Cart</button>
            </div>
        `;
        productGrid.appendChild(productCard);
    });
}

// Search products
searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filteredProducts = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm)
    );
    renderProducts(filteredProducts);
});

// Add to cart
productGrid.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart-button')) {
        const productId = parseInt(e.target.getAttribute('data-id'));
        addToCart(productId);
    }
});

function addToCart(productId) {
    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ id: productId, quantity: 1 });
    }
    updateCart();
}

// Remove from cart
function removeFromCart(productId) {
    const existingItem = cart.find(item => item.id === productId);
    if (existingItem && existingItem.quantity > 1) {
        existingItem.quantity--;
    } else {
        cart = cart.filter(item => item.id !== productId);
    }
    updateCart();
}

function updateCart() {
    cartItems.innerHTML = '';
    let total = 0;
    cart.forEach(item => {
        const product = products.find(p => p.id === item.id);
        const itemTotal = product.price * item.quantity;
        total += itemTotal;
        
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <h3>${product.name}</h3>
                <p>₹${product.price} x ${item.quantity}</p>
            </div>
            <div class="cart-item-actions">
                <button class="quantity-button minus" data-id="${product.id}">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-button plus" data-id="${product.id}">+</button>
            </div>
        `;
        cartItems.appendChild(cartItem);
    });
    
    cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartTotal.textContent = `₹${total}`;
}
cartButton.addEventListener('click', () => {
    cartPanel.classList.add('open');
});

closeCart.addEventListener('click', () => {
    cartPanel.classList.remove('open');
});

cartItems.addEventListener('click', (e) => {
    if (e.target.classList.contains('quantity-button')) {
        const productId = parseInt(e.target.getAttribute('data-id'));
        if (e.target.classList.contains('plus')) {
            addToCart(productId);
        } else if (e.target.classList.contains('minus')) {
            removeFromCart(productId);
        }
    }
});
renderProducts(products);
gsap.from('.product-card', {
    duration: 0.6,
    opacity: 0,
    y: 50,
    stagger: 0.1,
    ease: 'power2.out'
});

gsap.from('.cart-button', {
    duration: 0.6,
    opacity: 0,
    y: 20,
    ease: 'power2.out',
    delay: 0.5
});